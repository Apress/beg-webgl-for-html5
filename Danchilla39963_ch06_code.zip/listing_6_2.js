function setUniforms() {  
	var color_data = [
		255, 0, 0, 255,
		255, 0, 0, 255,
		255, 0, 0, 255,
		255, 0, 0, 255,

		255, 255, 0, 255,
		255, 255, 0, 255,
		255, 255, 0, 255,
		255, 255, 0, 255,

		0, 255, 0, 255,
		0, 255, 0, 255,
		0, 255, 0, 255,
		0, 255, 0, 255,

		0, 0, 255, 255,
		0, 0, 255, 255,
		0, 0, 255, 255,
		0, 0, 255, 255
	];
	var colors = new Uint8Array(color_data);

	var colorsTexture = gl.createTexture();
	gl.activeTexture(gl.TEXTURE0);
	gl.bindTexture(gl.TEXTURE_2D, colorsTexture);
	gl.texImage2D(	gl.TEXTURE_2D, 0, gl.RGBA, 4, 4, 0, 
	              	gl.RGBA, gl.UNSIGNED_BYTE, colors);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
	gl.uniform1i(gl.getUniformLocation(glProgram, "sColors"), colorsTexture);
 }
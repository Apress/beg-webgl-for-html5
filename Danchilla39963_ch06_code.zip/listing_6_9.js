function createGrid(size, divisions){
	size = (typeof size !== 'undefined') ? size : 1.0;
	divisions = (typeof divisions !== 'undefined') ? divisions : 10;

	var segment_size = size/divisions;
	var vertexPositionData = [];
	for(var i=0;i<=divisions;++i)
	{
		for(var j=0;j<=divisions;++j)
		{
			vertexPositionData.push(i*segment_size);
			vertexPositionData.push(0.0);
			vertexPositionData.push(j*segment_size);
		}
	}

	var indexData = [0];
	for(var row=0;row<divisions;++row)
	{
		if(row%2 == 0)
		{
			for(var i=0;i<=divisions;++i)
			{
				if(i!=0)
				{
					indexData.push( row*(divisions+1) + i);								
				}
				indexData.push( (row+1)*(divisions+1) + i);	
			}
		}else{
			for(var i=0;i<=divisions;++i)
			{
				if(i!=0)
				{
					indexData.push( (row+1)*(divisions+1) - (i+1) );	
				}
				indexData.push( (row+2)*(divisions+1) -(i+1) );	
			}						
		}	
	}

	//assign to buffers
}
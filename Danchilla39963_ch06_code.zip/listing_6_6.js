$("#sets").change(function(){
	if($(this).val() == "julia"){
		julia = 1;
	}else{
		julia = 0;
	}
});

$("#c-real, #c-imaginary").change(function(){
	var range = $(this);
	var value = parseFloat(range.val());
	if(range.attr("id") == "c-real")
	{
		c_seed[0] = value;
	}else if(range.attr("id") == "c-imaginary")
	{
		c_seed[1] = value;
	}	
	
	setCLabel();
});

$(".color-slider").change(function(){
	var range = $(this);
	var value = parseFloat(range.val());
	
	if(range.attr("id") == "color-r")
	{
		color[0] = value;
	}else if(range.attr("id") == "color-g")
	{
		color[1] = value;
	}else if(range.attr("id") == "color-b")
	{
		color[2] = value;
	}else if(range.attr("id") == "lightness")
	{
		lightness = value;
	}	
	
	setColorLabel();
});

$("form").on("click", "input:submit", function(evt){
	var name = $(this).attr("name");
	
	switch(name){
		case 'up':
			offset[1] += (0.1 * zoom);
			break;
		case 'down':
			offset[1] -= (0.1 * zoom);
			break;
		case 'left':
			offset[0] -= (0.1 * zoom);
			break;
		case 'right':
			offset[0] += (0.1 * zoom);
			break;
		case 'zoom-in':
			zoom /= 1.5;
			break;
		case 'zoom-out':
			zoom *= 1.5;
			break;	
		case 'reset':
			resetUniformVariables();
			$("#c-real").val(0.00);
			$("#c-imaginary").val(0.00);
			$("#color-r").val(0.1);
			$("#color-g").val(0.1);
			$("#color-b").val(1.0);
			$("#lightness").val(1.0);
			$("#sets").val("mandebrot");				
			setColorLabel();
			setCLabel();
			break;			
		default:
			break;			
	}
	
	setTextArea();
	
	evt.preventDefault();
});
</script>	
</body>
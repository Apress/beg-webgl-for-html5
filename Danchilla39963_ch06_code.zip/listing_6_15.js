function adjustParticles(){
	var particles_old = particles.slice(); //copy
	particles = [];
	for( var i=0; i<particles_old.length; i+=PARTICLE_COMPONENTS )
	{
		//remove old particles
    	//if past lifespan or below the start position, do not readd particle
    	if( (particles_old[i+3] < LIFESPAN) && 
    		(particles_old[i+1] > (START_Y - 0.001) )
    		)
    	{	var old = particles_old.slice(i, i+PARTICLE_COMPONENTS );
    		old[3] += 1.0; //age
    		particles = particles.concat(old);
    	}
    }

    currentNumberParticles = particles.length/PARTICLE_COMPONENTS;
    	
    //spawn new particles            	
	if( currentNumberParticles + MAX_SPAWN_PER_FRAME < MAX_NUMBER_OF_PARTICLES )
	{
		for( var n=0; n<MAX_SPAWN_PER_FRAME; ++n )
		{
    		particles.push(.5*Math.random()-.25);		//X
    		particles.push(START_Y);					//Y
    		particles.push(Math.random() - .5);			//Z
    		particles.push(0.0); 						//age

    		particles.push(5.0*Math.random() - 10.0);	//velX
    		particles.push(14.0 + 12.0*Math.random());	//velY
    		particles.push(0.5 + Math.random() *4.0);	//size
    		++currentNumberParticles;
		}
	}
}
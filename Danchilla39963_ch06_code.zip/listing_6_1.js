function createSquare(size){
	size = (typeof size !== 'undefined') ? size : 2.0;

	var vertexPositionData = [
		0.0, 0.0,  0.0,
		-size/2.0, -size/2.0, 0.0,
		size/2.0, -size/2.0, 0.0,
		size/2.0, size/2.0, 0.0,
		-size/2.0,size/2.0, 0.0,  	
	];

	var indexData = [0,1,2,0,2,3,0,3,4,0,4,1];

	trianglesVerticeBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, trianglesVerticeBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositionData), gl.STATIC_DRAW);
	trianglesVerticeBuffer.itemSize = 3;
	trianglesVerticeBuffer.numItems = vertexPositionData.length / 3;

	vertexIndexBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, vertexIndexBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indexData), gl.STREAM_DRAW);
	vertexIndexBuffer.itemSize = 3;
	vertexIndexBuffer.numItems = indexData.length;
}
<form id='fractal-options'>
	<table border="0">
		<tr>
			<td>
				<select id="sets">
					<option value="mandelbrot">Mandelbrot</option>
					<option value="julia">Julia</option>
				</select>
			</td>
			<td>
			</td>
	</tr>
	<tr>
		<td>
			<input type="submit" name="up" value="Up"/><br/>
			<input type="submit" name="left" value="<-"/>
			<input type="submit" name="right" value="->"/><br/>
			<input type="submit" name="down" value="Down"/>
		</td>
		<td rowspan="2">
			<textarea cols="30" rows="2" id="output-text">Offset: (0.00, 0.00)&#10;Zoom level: x1</textarea>
	</tr>
	<tr>
		<td>
			<input type="submit" name="zoom-in" value="Zoom in"/><br/>
			<input type="submit" name="zoom-out" value="Zoom out"/>
		</td>

	</tr>
	<tr>
		<td>
			C value: (<span id="c-value-label">0.00, 0.00</span>)<br/> 
			Real: <input type="range" step="0.01" id="c-real" name="c-real" value="0.0" min="-2" max="2"/><br/> 
			Imaginary: <input type="range" step="0.01" id="c-imaginary" name="c-imaginary" value="0.0" min="-2" max="2"/>
		</td>
		<td>
			Color: (<span id="color-label">0.1, 0.1, 1.0</span>)<br/> 
			R: <input type="range" step="0.1" class="color-slider" id="color-r" name="color-r" value="0.1" min="0.0" max="1.0"/><br/> 
			G: <input type="range" step="0.1" class="color-slider" id="color-g" name="color-g" value="0.1" min="0.0" max="1.0"/><br/> 
			B: <input type="range" step="0.1" class="color-slider" id="color-b" name="color-b" value="1.0" min="0.0" max="1.0"/><br/> 					
			<br/><br/>
			Lightness: <input type="range" step="1.0" class="color-slider" id="lightness" name="lightness" value="1.0" min="1.0" max="50.0"/> 
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input type="submit" name="reset" value="Reset"/>
		</td>
	</tr>
</form>
<script id="shader-fs" type="x-shader/x-fragment">
	varying highp vec4 color;

	void main(void) {   
		gl_FragColor = color;
	}
</script>
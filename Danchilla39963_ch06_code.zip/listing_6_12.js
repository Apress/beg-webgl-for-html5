function midpointDisplacement(tl, tr, bl, br, divisions,iteration)
{				
	if( (tl[0] + 1) == br[0] || 	(tl[1] + 1) == br[1] )
	{
		return;
	}

	//array indices
	var midpoint = [	(tl[0] + br[0])/2, 
						(tl[1] + br[1])/2
					];
	
	var left_mp = [	tl[0], 
					(tl[1] + bl[1])/2
					];
	var right_mp = [ tr[0], 
					 (tr[1] + br[1])/2
					 ];
	var top_mp = [	(tl[0] + tr[0])/2, 
					tl[1]
				];
	var bottom_mp = [	(bl[0] + br[0])/2, 
						bl[1]]; 

	//current height values
	var tl_height = vertexPositionData[(tl[0] + tl[1] * (divisions+1))*3+1];
	var tr_height = vertexPositionData[(tr[0] + tr[1] * (divisions+1))*3+1];
	var bl_height = vertexPositionData[(bl[0] + bl[1] * (divisions+1))*3+1];
	var br_height = vertexPositionData[(br[0] + br[1] * (divisions+1))*3+1];

	//computer five new points
	var top_value = (tl_height + tr_height)/2.0;
	vertexPositionData[(top_mp[0] + top_mp[1] * (divisions+1))*3+1] = top_value;
	var bottom_value = (bl_height + br_height)/2.0;
	vertexPositionData[(bottom_mp[0] + bottom_mp[1] * (divisions+1))*3+1] = bottom_value;

	var left_value = (tl_height + bl_height)/2.0;
	vertexPositionData[(left_mp[0] + left_mp[1] * (divisions+1))*3+1] = left_value;
	var right_value = (tr_height + br_height)/2.0;
	vertexPositionData[(right_mp[0] + right_mp[1] * (divisions+1))*3+1] = right_value;

	//midpoint has random term
	vertexPositionData[(midpoint[0] + midpoint[1] * (divisions+1)) * 3 + 1] = (tl_height+tr_height+bl_height+br_height)/4.0 
		+(-0.5+Math.random())*Math.pow(0.65, iteration-2.0);

	//repeat with four quads	
	midpointDisplacement( tl, top_mp, left_mp, midpoint, divisions, iteration+1 );
	midpointDisplacement( top_mp, tr, midpoint, right_mp, divisions, iteration+1 );
	midpointDisplacement( left_mp, midpoint, bl, bottom_mp, divisions, iteration+1 );
	midpointDisplacement( midpoint, right_mp, bottom_mp, br, divisions, iteration+1 );
}
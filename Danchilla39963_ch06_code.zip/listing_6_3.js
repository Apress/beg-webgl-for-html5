znext.x = z.x*z.x - z.y*z.y + c.x;
znext.y = 2*z.x*z.y + c.y;

function resetUniformVariables()
{
	c_seed = [0.0, 0.0];
	zoom = 1.0;
	offset = [0.0, 0.0];
	julia = 0;
	color = [0.1, 0.1, 1.0];
	lightness = 1.0;
}	

function setColorLabel()
{
	$("#color-label").html(color[0].toFixed(1) + ", " + color[1].toFixed(1) + ", " + color[2].toFixed(1));
}

function setCLabel()
{
	$("#c-value-label").html(c_seed[0].toFixed(2) + ", " + c_seed[1].toFixed(2));
}

function setTextArea()
{
		var zoom_reciprocal = 'MAX ZOOM';
		if(zoom > 0.00000000001)
		{
			zoom_reciprocal = 1.0/zoom;
		}
		var settings = "Offset: (" + offset[0].toFixed(2) + "," +offset[1].toFixed(2) + ")\n";
		settings += "Zoom level: x" + zoom_reciprocal;
		$("#output-text").html(settings) ;
}
<script id="shader-fs" type="x-shader/x-fragment">
	varying highp vec4 vColor;
	void main(void) {
       gl_FragColor = vColor;
	}
</script>
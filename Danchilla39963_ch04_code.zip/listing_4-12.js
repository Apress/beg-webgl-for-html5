var drawOrder = [1,2,3,0];
for(var n=0; n < drawOrder.length; ++n)
{
	var i = drawOrder[n];
	gl.bindBuffer(gl.ARRAY_BUFFER, trianglesVerticeBuffers[i]);
	gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);

	gl.bindBuffer(gl.ARRAY_BUFFER, trianglesColorBuffers[i]);
	gl.vertexAttribPointer(vertexColorAttribute, 4, gl.FLOAT, false, 0, 0);

	gl.bindBuffer(gl.ARRAY_BUFFER, trianglesNormalBuffers[i]);
	gl.vertexAttribPointer(vertexNormalAttribute, 3, gl.FLOAT, false, 0, 0);
	
	if(i==0){
		gl.disable(gl.DEPTH_TEST);
		gl.enable(gl.BLEND);
		gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
		gl.blendEquation(gl.FUNC_ADD);
	}else{
		gl.disable(gl.BLEND);
		gl.enable(gl.DEPTH_TEST);
	}
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, vertexIndexBuffers[i]);
	gl.drawElements(gl.TRIANGLES, vertexIndexBuffers[i].numItems, gl.UNSIGNED_SHORT, 0);
}

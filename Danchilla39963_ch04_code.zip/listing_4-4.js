if(!smooth_shading)
  {
  		vertexPositionData = calculateFlattenedVertices(
vertexPositionData, indexData);
	  	colorData = [];
	  	for(var i=0; i<indexData.length;++i)
	  	{
	  		colorData.push(color[0]);
	      		colorData.push(color[1]);
		       	colorData.push(color[2]);	      
		       	colorData.push(color[3]);
	  	}	
	  	normalData = calculatePerFaceNormals(normalData, indexData);
	  }
…
function calculateFlattenedVertices(origVertices, indices)
{
	var vertices = [];
	for(var i=0; i<indices.length; ++i)
	{
		a = indices[i]*3;
		vertices.push(origVertices[a]);
		vertices.push(origVertices[a + 1]);
		vertices.push(origVertices[a + 2]);
	}	
	return vertices;
}

function calculatePerFaceNormals(origNormals, indices)
{
	var normals = [];
	for(var i=0; i<indices.length; i+=3)
	{
		var a = indices[i]*3;
		var b = indices[i+1]*3;
		var c = indices[i+2]*3;
		
		n1 = new Vector3(origNormals[a], origNormals[a+1], origNormals[a+2]);
		n2 = new Vector3(origNormals[b], origNormals[b+1], origNormals[b+2]);
		n3 = new Vector3(origNormals[c], origNormals[c+1], origNormals[c+2]);

		nx = (n1.x + n2.x + n3.x)/3;
		ny = (n1.y + n2.y + n3.y)/3;
		nz = (n1.z + n2.z + n3.z)/3;

		v3 = new Vector3(nx,ny,nz);
		normals.push(v3.x);
		normals.push(v3.y);
		normals.push(v3.z);

		normals.push(v3.x);
		normals.push(v3.y);
		normals.push(v3.z);

		normals.push(v3.x);
		normals.push(v3.y);
		normals.push(v3.z);
	}	
	return normals;
}

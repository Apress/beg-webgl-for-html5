highp vec3 pointLightDirection = vec3(pointLightPosition.xyz - vPosition.xyz);
highp float d = length(pointLightDirection);
highp float attenuation = 1.0/(.01 + .01*d+.02*d*d);
�

highp vec3 AmbientColour = vec3(0.1, 0.1, 0.1)*attenuation;
highp vec3 DiffuseMaterialColour = vColor.xyz*attenuation;
highp vec3 SpecularColour = vec3(1.0, 1.0, 1.0)*attenuation;
